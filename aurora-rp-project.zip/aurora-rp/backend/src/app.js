import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { z } from 'zod';
import { rateLimit } from 'express-rate-limit';
import { pool } from './db.js';
import { requireAuth } from './auth.js';

export const app = express();
app.disable('x-powered-by');
app.use(helmet());
app.use(cors({
  origin: (process.env.CORS_ORIGIN || '').split(',').map(x => x.trim()).filter(Boolean),
  methods: ['GET', 'POST'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));
app.use(express.json({ limit: '16kb' }));

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 10,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: { error: 'Muitas tentativas. Tente novamente mais tarde.' }
});

app.get('/health', (_req, res) => res.json({ status: 'ok', service: 'aurora-rp-api' }));

const registerSchema = z.object({
  email: z.string().email().max(190),
  password: z.string().min(10).max(72),
  displayName: z.string().trim().min(2).max(80)
});

app.post('/v1/auth/register', authLimiter, async (req, res, next) => {
  try {
    const parsed = registerSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: 'Dados inválidos.' });
    const { email, password, displayName } = parsed.data;
    const hash = await bcrypt.hash(password, 12);
    try {
      const result = await pool.query(
        'INSERT INTO app_users (email, password_hash, display_name) VALUES (?, ?, ?)',
        [email.toLowerCase(), hash, displayName]
      );
      return res.status(201).json({ id: Number(result.insertId), message: 'Conta criada.' });
    } catch (err) {
      if (err.code === 'ER_DUP_ENTRY') return res.status(409).json({ error: 'E-mail já cadastrado.' });
      throw err;
    }
  } catch (err) { next(err); }
});

const loginSchema = z.object({
  email: z.string().email().max(190),
  password: z.string().min(1).max(72)
});

app.post('/v1/auth/login', authLimiter, async (req, res, next) => {
  try {
    const parsed = loginSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: 'Credenciais inválidas.' });
    const { email, password } = parsed.data;
    const rows = await pool.query(
      'SELECT id, email, password_hash, display_name FROM app_users WHERE email = ? LIMIT 1',
      [email.toLowerCase()]
    );
    const user = rows[0];
    if (!user || !(await bcrypt.compare(password, user.password_hash))) {
      return res.status(401).json({ error: 'E-mail ou senha incorretos.' });
    }
    const token = jwt.sign(
      { sub: String(user.id), email: user.email },
      process.env.JWT_SECRET,
      { algorithm: 'HS256', expiresIn: process.env.JWT_EXPIRES_IN || '2h' }
    );
    return res.json({
      accessToken: token,
      tokenType: 'Bearer',
      expiresIn: process.env.JWT_EXPIRES_IN || '2h',
      user: { id: Number(user.id), email: user.email, displayName: user.display_name }
    });
  } catch (err) { next(err); }
});

app.get('/v1/me', requireAuth, async (req, res, next) => {
  try {
    const rows = await pool.query(
      'SELECT id, email, display_name, qbox_citizenid, created_at FROM app_users WHERE id = ? LIMIT 1',
      [Number(req.auth.sub)]
    );
    if (!rows[0]) return res.status(404).json({ error: 'Conta não encontrada.' });
    const u = rows[0];
    return res.json({
      id: Number(u.id), email: u.email, displayName: u.display_name,
      characterLinked: Boolean(u.qbox_citizenid), createdAt: u.created_at
    });
  } catch (err) { next(err); }
});

app.use((err, _req, res, _next) => {
  // Não expor SQL, stack traces ou segredos ao cliente.
  console.error('[api-error]', err?.code || 'INTERNAL_ERROR');
  res.status(500).json({ error: 'Erro interno do servidor.' });
});
