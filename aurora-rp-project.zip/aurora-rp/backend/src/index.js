import 'dotenv/config';
import { app } from './app.js';

const required = ['JWT_SECRET', 'DB_HOST', 'DB_NAME', 'DB_USER', 'DB_PASSWORD'];
for (const key of required) {
  if (!process.env[key]) {
    console.error(`Configuração obrigatória ausente: ${key}`);
    process.exit(1);
  }
}
if (process.env.JWT_SECRET.length < 32) {
  console.error('JWT_SECRET precisa ter pelo menos 32 caracteres.');
  process.exit(1);
}

const port = Number(process.env.PORT || 8080);
app.listen(port, '0.0.0.0', () => {
  console.log(`Aurora RP API ouvindo na porta ${port}`);
});
