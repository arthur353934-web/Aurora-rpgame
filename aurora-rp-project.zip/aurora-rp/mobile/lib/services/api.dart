import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class Api {
  // Em produção, substitua pelo domínio HTTPS público da sua API.
  static const String baseUrl = String.fromEnvironment(
    'API_BASE_URL',
    defaultValue: 'http://10.0.2.2:8080',
  );
  static const storage = FlutterSecureStorage();

  static Future<Map<String, dynamic>> login(String email, String password) async {
    final response = await http.post(
      Uri.parse('$baseUrl/v1/auth/login'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'email': email, 'password': password}),
    );
    final data = jsonDecode(response.body) as Map<String, dynamic>;
    if (response.statusCode != 200) {
      throw Exception(data['error'] ?? 'Não foi possível entrar.');
    }
    await storage.write(key: 'access_token', value: data['accessToken'] as String);
    return data['user'] as Map<String, dynamic>;
  }

  static Future<Map<String, dynamic>> me() async {
    final token = await storage.read(key: 'access_token');
    if (token == null) throw Exception('Faça login novamente.');
    final response = await http.get(
      Uri.parse('$baseUrl/v1/me'),
      headers: {'Authorization': 'Bearer $token'},
    );
    final data = jsonDecode(response.body) as Map<String, dynamic>;
    if (response.statusCode != 200) throw Exception(data['error'] ?? 'Sessão inválida.');
    return data;
  }

  static Future<void> logout() => storage.delete(key: 'access_token');
}
