import 'package:flutter/material.dart';
import '../services/api.dart';
import 'home_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final email = TextEditingController();
  final password = TextEditingController();
  bool loading = false;
  String? error;

  Future<void> submit() async {
    setState(() { loading = true; error = null; });
    try {
      await Api.login(email.text.trim(), password.text);
      if (!mounted) return;
      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const HomeScreen()));
    } catch (e) {
      setState(() => error = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  void dispose() { email.dispose(); password.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(26),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 440),
              child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                const Icon(Icons.blur_on, size: 64, color: Color(0xFF55CFC3)),
                const SizedBox(height: 12),
                const Text('AURORA RP', textAlign: TextAlign.center, style: TextStyle(fontSize: 27, fontWeight: FontWeight.w800, letterSpacing: 4)),
                const Text('SEU MUNDO. SUA HISTÓRIA.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white54, letterSpacing: 2, fontSize: 10)),
                const SizedBox(height: 42),
                const Text('Entrar na sua conta', style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
                const SizedBox(height: 20),
                TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'E-mail')),
                const SizedBox(height: 12),
                TextField(controller: password, obscureText: true, decoration: const InputDecoration(labelText: 'Senha')),
                if (error != null) Padding(padding: const EdgeInsets.only(top: 12), child: Text(error!, style: const TextStyle(color: Colors.redAccent))),
                const SizedBox(height: 20),
                FilledButton(onPressed: loading ? null : submit, child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: loading ? const CircularProgressIndicator() : const Text('ENTRAR'),
                )),
                const SizedBox(height: 12),
                const Text('A conta mobile é separada da conta Cfx.re. A vinculação ao personagem será habilitada na próxima integração.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white38, fontSize: 11)),
              ]),
            ),
          ),
        ),
      ),
    );
  }
}
