import 'package:flutter/material.dart';
import '../services/api.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  Map<String, dynamic>? profile;
  String? error;

  @override
  void initState() { super.initState(); load(); }

  Future<void> load() async {
    try {
      final data = await Api.me();
      if (mounted) setState(() => profile = data);
    } catch (e) {
      if (mounted) setState(() => error = e.toString());
    }
  }

  Future<void> logout() async {
    await Api.logout();
    if (!mounted) return;
    Navigator.of(context).pushNamedAndRemoveUntil('/', (_) => false);
  }

  @override
  Widget build(BuildContext context) {
    final p = profile;
    return Scaffold(
      appBar: AppBar(title: const Text('AURORA RP'), actions: [IconButton(onPressed: logout, icon: const Icon(Icons.logout))]),
      body: RefreshIndicator(
        onRefresh: load,
        child: ListView(padding: const EdgeInsets.all(20), children: [
          const Text('PAINEL DO CIDADÃO', style: TextStyle(color: Color(0xFF55CFC3), letterSpacing: 2, fontSize: 11)),
          const SizedBox(height: 10),
          Text(p?['displayName'] ?? (error ?? 'Carregando perfil...'), style: const TextStyle(fontSize: 27, fontWeight: FontWeight.bold)),
          const SizedBox(height: 20),
          _tile(Icons.account_circle, 'Personagem', p?['characterLinked'] == true ? 'Personagem vinculado' : 'Ainda não vinculado'),
          _tile(Icons.account_balance_wallet, 'Banco', 'Disponível após integração segura com Qbox'),
          _tile(Icons.directions_car, 'Veículos', 'Disponível após integração'),
          _tile(Icons.chat_bubble_outline, 'Mensagens', 'Disponível após integração'),
          _tile(Icons.notifications, 'Notificações', 'Em desenvolvimento'),
          const SizedBox(height: 20),
          const Text('O aplicativo não executa GTA V/FiveM e não acessa o banco de dados diretamente.', style: TextStyle(color: Colors.white54, fontSize: 12)),
        ]),
      ),
    );
  }

  Widget _tile(IconData icon, String title, String subtitle) => Card(
    color: const Color(0xFF172235),
    child: ListTile(leading: Icon(icon, color: const Color(0xFF55CFC3)), title: Text(title), subtitle: Text(subtitle)),
  );
}
