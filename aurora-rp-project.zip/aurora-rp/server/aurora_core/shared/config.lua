Config = {}

Config.Locale = 'pt-BR'
Config.Command = 'aurora'
Config.OpenKey = 'F6'

-- Recursos Qbox/Overextended são instalados separadamente pela receita oficial.
Config.Integrations = {
    inventory = 'ox_inventory',
    voice = 'pma-voice'
}
