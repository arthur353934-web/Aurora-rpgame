local isOpen = false

local function setUi(state)
    isOpen = state
    SetNuiFocus(state, state)
    SendNUIMessage({ action = state and 'open' or 'close' })
    if state then
        lib.callback('aurora:server:getProfile', false, function(profile)
            SendNUIMessage({ action = 'profile', profile = profile or {} })
        end)
    end
end

RegisterCommand(Config.Command, function()
    setUi(not isOpen)
end, false)

RegisterKeyMapping(Config.Command, 'Abrir painel Aurora RP', 'keyboard', Config.OpenKey)

RegisterNUICallback('close', function(_, cb)
    setUi(false)
    cb({ ok = true })
end)

RegisterNUICallback('requestProfile', function(_, cb)
    lib.callback('aurora:server:getProfile', false, function(profile)
        cb({ ok = profile ~= nil, profile = profile or {} })
    end)
end)
