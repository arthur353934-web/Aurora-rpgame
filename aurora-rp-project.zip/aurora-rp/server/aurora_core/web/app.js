const app = document.getElementById('app');
const money = value => new Intl.NumberFormat('pt-BR',{style:'currency',currency:'BRL'}).format(Number(value)||0);
window.addEventListener('message', event => {
  const data = event.data || {};
  if (data.action === 'open') app.classList.remove('hidden');
  if (data.action === 'close') app.classList.add('hidden');
  if (data.action === 'profile') {
    const p = data.profile || {};
    document.getElementById('player-name').textContent = `${p.firstName||'Cidadão'} ${p.lastName||''}`.trim();
    document.getElementById('player-job').textContent = p.job || 'Desempregado';
    document.getElementById('cash').textContent = money(p.cash);
    document.getElementById('bank').textContent = money(p.bank);
  }
});
document.getElementById('close').addEventListener('click', () => {
  fetch(`https://${GetParentResourceName()}/close`, {method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});
});
document.addEventListener('keydown', e => { if(e.key === 'Escape') document.getElementById('close').click(); });
document.querySelectorAll('[data-page]').forEach(button => button.addEventListener('click', () => {
  // Navegação visual inicial; telas transacionais serão integradas em etapas seguintes.
  button.blur();
}));
