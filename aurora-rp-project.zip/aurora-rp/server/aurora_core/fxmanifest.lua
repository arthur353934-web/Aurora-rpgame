fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'aurora_core'
author 'Aurora RP'
description 'Integrações iniciais do Aurora RP com Qbox'
version '0.1.0'

shared_scripts {
    '@ox_lib/init.lua',
    'shared/config.lua'
}

client_scripts {
    'client/main.lua'
}

server_scripts {
    'server/main.lua'
}

ui_page 'web/index.html'

files {
    'web/index.html',
    'web/style.css',
    'web/app.js'
}

dependencies {
    'qbx_core',
    'ox_lib'
}
