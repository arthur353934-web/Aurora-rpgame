local function getPlayerSummary(src)
    local player = exports.qbx_core:GetPlayer(src)
    if not player or not player.PlayerData then return nil end

    local data = player.PlayerData
    local charinfo = data.charinfo or {}
    local money = data.money or {}

    return {
        serverId = src,
        citizenid = data.citizenid,
        firstName = charinfo.firstname or 'Cidadão',
        lastName = charinfo.lastname or '',
        job = (data.job and data.job.label) or 'Desempregado',
        cash = tonumber(money.cash) or 0,
        bank = tonumber(money.bank) or 0
    }
end

lib.callback.register('aurora:server:getProfile', function(source)
    return getPlayerSummary(source)
end)

RegisterNetEvent('aurora:server:requestProfile', function()
    local src = source
    local profile = getPlayerSummary(src)
    TriggerClientEvent('aurora:client:profile', src, profile)
end)

AddEventHandler('playerDropped', function()
    -- Qbox/oxmysql gerenciam persistência do personagem; não duplicar salvamento aqui.
end)

print('^2[Aurora RP]^7 aurora_core iniciado. Integração Qbox básica carregada.')
