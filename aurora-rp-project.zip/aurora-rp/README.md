# Aurora RP — projeto inicial

Projeto inicial de servidor GTA V RP para **FiveM + Qbox**, com interface NUI,
backend HTTP seguro e aplicativo Android em Flutter.

> Estado: scaffold de desenvolvimento. Não é um servidor já instalado ou online,
> não inclui GTA V, FXServer, chaves Cfx.re, assets pagos ou arquivos proprietários.
> O APK ainda precisa ser compilado por Flutter/Android SDK (localmente ou via GitHub Actions).

## Estrutura

- `server/`: recurso FiveM próprio `aurora_core` (Lua).
- `web/`: interface NUI em HTML/CSS/JavaScript.
- `backend/`: API Node.js, autenticação JWT, MariaDB e rate limit.
- `mobile/`: aplicativo Flutter Android.
- `database/`: schema exclusivo da API mobile.
- `.github/workflows/`: validação e compilação Android via GitHub Actions.
- `docs/`: instalação e checklist de integração.

## O que já existe neste pacote

- Recurso FiveM com manifesto, configuração e callbacks/eventos server-side.
- NUI de demonstração em português, com navegação e telas ilustrativas.
- API com cadastro/login, JWT, perfil e health check.
- Senhas com hash bcrypt; CORS configurável; Helmet; rate limiting.
- Aplicativo Flutter com login, armazenamento seguro do token e dashboard.
- Workflow GitHub Actions para compilar APK de release.
- Modelo SQL separado para contas do aplicativo.

## O que ainda precisa ser conectado/testado

1. Instalar FXServer/txAdmin e Qbox seguindo a documentação oficial.
2. Configurar `oxmysql`, `ox_lib`, `ox_inventory` e `pma-voice` conforme a receita Qbox escolhida.
3. Revisar a versão atual de Qbox e validar os exports/eventos com a instalação concreta.
4. Integrar o backend com a identidade/characters do Qbox, sem expor MariaDB ao celular.
5. Integrar banco, mensagens, veículos e notificações com eventos server-side autenticados.
6. Executar testes em servidor FiveM real e em dispositivo Android.

## Requisitos

- Servidor: FXServer compatível com Qbox, MariaDB, `oxmysql`.
- Backend: Node.js 20+ e MariaDB 10.9+ (preferir uma versão LTS suportada pelo Qbox).
- Android: Flutter stable atual + Android SDK para build local; ou GitHub Actions.
- Não publique `.env`, senhas, tokens, `server.cfg` com chave Cfx.re ou dados pessoais.

## Início rápido

Consulte `docs/INSTALL.md`. Para desenvolvimento, copie `backend/.env.example` para
`backend/.env`, configure os valores e execute `docker compose up -d db` na raiz.
Depois execute `npm install` e `npm run dev` em `backend/`.

## Licença

Os arquivos originais deste scaffold são disponibilizados sob MIT (ver `LICENSE`).
Isso não concede direitos sobre GTA V, FiveM, Qbox, recursos de terceiros, mapas,
veículos, roupas, marcas ou outros assets. Cada dependência mantém sua própria licença.
