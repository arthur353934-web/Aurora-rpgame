# API inicial

Base local: `http://localhost:8080`

- `GET /health` — status da API.
- `POST /v1/auth/register` — `{ "email", "password", "displayName" }`.
- `POST /v1/auth/login` — `{ "email", "password" }`; retorna JWT.
- `GET /v1/me` — exige `Authorization: Bearer <token>`.

Ainda não há endpoints de banco, mensagens, veículos ou negócios. Eles só devem ser
adicionados após implementar vínculo de conta/personagem e autorização server-side.
