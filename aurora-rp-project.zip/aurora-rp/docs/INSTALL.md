# Instalação e publicação

## A. GitHub pelo celular

1. Baixe e extraia `aurora-rp-project.zip`.
2. No GitHub, crie um repositório vazio chamado `aurora-rp`.
3. Use o app GitHub ou o navegador para enviar os arquivos extraídos.
4. Não envie `.env`, chaves Cfx.re, senhas, certificados ou backups reais.
5. Aguarde a aba **Actions** executar o workflow Android.

## B. APK via GitHub Actions

O workflow `.github/workflows/android-apk.yml` executa `flutter build apk --release`.
Depois de concluído, abra a execução em Actions e baixe o artefato `aurora-rp-android-apk`.
O APK só existirá depois que a compilação terminar com sucesso.

Configure a URL da API no workflow/compilação com `--dart-define=API_BASE_URL=https://SEU-DOMINIO`.
A API precisa estar publicada em HTTPS e acessível pelo celular. Não use localhost no APK de produção.

## C. Backend local/desenvolvimento

1. Copie `backend/.env.example` para `backend/.env`.
2. Defina senhas fortes e um JWT_SECRET aleatório de pelo menos 32 caracteres.
3. Na raiz, crie `.env` com `DB_PASSWORD` e `DB_ROOT_PASSWORD`.
4. Execute `docker compose up -d db`.
5. Em `backend/`, execute `npm install` e `npm run dev`.
6. Verifique `http://localhost:8080/health`.

Não exponha a porta MariaDB à internet. O compose vincula o banco a `127.0.0.1`.

## D. FiveM/Qbox

1. Instale FXServer e txAdmin em Windows seguindo a documentação Cfx.re.
2. Instale a receita oficial Qbox Stable pelo txAdmin.
3. Confirme que `qbx_core` e `ox_lib` iniciam sem erros.
4. Copie `server/aurora_core` para a pasta `resources/[local]/aurora_core`.
5. Adicione ao `server.cfg`, depois das dependências:
   `ensure aurora_core`
6. Reinicie o servidor e conecte com FiveM.
7. Digite `/aurora` ou pressione F6.

O recurso é uma integração inicial. Ele não substitui criação/seleção de personagens, inventário, garagem, polícia, hospital ou persistência fornecidos pelos recursos Qbox. Teste em servidor de desenvolvimento antes de produção.

## E. Estado de compatibilidade

O código usa `exports.qbx_core:GetPlayer(source)` e callback de `ox_lib`. Confirme esses contratos com as versões instaladas. Não foi possível testar neste ambiente porque FXServer, Qbox, MariaDB, Flutter e Android SDK não estão instalados.

## F. Segurança antes de produção

- HTTPS obrigatório para a API.
- JWT_SECRET único e forte.
- CORS limitado ao domínio real.
- Firewall e backups automatizados.
- Não confiar em valores de dinheiro/inventário enviados pelo cliente.
- Vincular conta mobile ao personagem com fluxo de prova de posse, nunca por citizenid informado livremente.
- Implementar autorização por usuário e auditoria em cada endpoint transacional.
